# IDOL DocumentSecurity API — Helm chart <!-- omit in toc -->

Deploys the DocumentSecurity API, which manages identity repositories and the group memberships
that connectors attach to documents for access control. Usable on its own, and bundled as a
sub-chart by `idol-connector-management`, whose NiFi `PutUserSecurity` processor pushes to it.

Every object is named `<release>-documentsecurity` (the bundled database
`<release>-docsec-postgresql`), so several releases can coexist in one namespace — including two
parent releases that each bundle this chart. See [Object naming](#object-naming).

## Table of contents <!-- omit in toc -->

- [Quick start](#quick-start)
- [Database](#database)
- [Object naming](#object-naming)
- [Ingress](#ingress)
- [Identity repositories](#identity-repositories)
- [Credentials and Secrets](#credentials-and-secrets)
- [Uninstalling and cleaning up](#uninstalling-and-cleaning-up)
- [Known limitations](#known-limitations)

# Quick start

```sh
helm dependency update .
helm install docsec . -n <namespace>
```

That deploys the API with a bundled `postgresql-ha` database, on port 8080, with an nginx Ingress
and no authentication. Nothing is required beyond an image it can pull — see
[Known limitations](#known-limitations) for what the defaults assume.

# Database

Three configurations, in the order the chart checks them.

**1. A connection string you supply.** Takes over completely; supply the credentials with it.

```yaml
documentsecurity:
  env:
    DOCUMENTSECURITY_DB_CONNECTIONSTRING: "jdbc:postgresql://host:5432/db"
```

**2. An existing instance** — a managed service, or a database owned by a parent chart. Set
`postgresql.enabled=false` so no second database is deployed:

```yaml
postgresql:
  enabled: false
externalPostgresql:
  host: my-instance.example.com
  port: 5432
  database: idol-documentsecurity
  username: postgres
  password: <password>          # or existingSecret, below
```

`host` is passed through `tpl`, so a parent chart can point this at a Service it owns with a
release-scoped value like `'{{ .Release.Name }}-postgresql-pgpool'`.

**3. The bundled `postgresql-ha` sub-chart** (the default, `postgresql.enabled=true`). Everything
under `postgresql` other than `enabled`, `existingSecret` and the naming overrides is bitnami's
own configuration, passed through untouched.

With none of the three, the API falls back to an embedded HSQLDB at
`/opt/documentsecurity/data/db`. That has no volume behind it, so it is for smoke-testing only —
its contents do not survive the pod.

The two blocks are deliberately separate: `externalPostgresql` describes an instance this chart
does **not** deploy, while `postgresql` configures the one it does. `idol-connector-management`
splits its own values the same way.

# Object naming

| Object | Name |
|--------|------|
| API StatefulSet, Service, Ingress | `<release>-documentsecurity` |
| API ConfigMap | `<release>-documentsecurity-cm` |
| Credential Secret | `<release>-documentsecurity-credentials` |
| Bundled database | `<release>-docsec-postgresql-*` |

`documentsecurity.fullnameOverride` replaces the whole name and is passed through `tpl`, so a
parent chart can supply a release-scoped name from its own static values and resolve the same
string itself — which is how `idol-connector-management` references this Service.
`documentsecurity.nameOverride` replaces only the part after the release name.

The bundled database uses `postgresql.nameOverride`, **not** `fullnameOverride`, for two reasons.
bitnami builds its names as `<release>-<nameOverride>`, so the result stays release-scoped, where
a literal `fullnameOverride` is the same string in every release. And bitnami selects pods on
`app.kubernetes.io/name` (that value) plus `app.kubernetes.io/instance` and nothing else, so it is
the only one of the two that separates the *selectors* from a parent chart's own `postgresql-ha` —
with `fullnameOverride` the objects are renamed but every Service still matches both clusters'
pods, including the headless Service repmgr uses for cluster membership.

The name is abbreviated because bitnami appends component and role suffixes: the longest rendered
name is `<release>-<this>-postgresql-headless`, and the 63-character DNS limit is reachable with a
long release name.

# Ingress

`documentsecurity.ingress.enabled` defaults to **true**. Set a host, a `contextPath`, or both:
with neither, the rule has no host and matches every hostname the controller serves, which on a
shared cluster takes traffic from anything else published at that path.

```yaml
documentsecurity:
  ingress:
    host: docsec.example.com
    contextPath: /doc-sec
    tls:
      secretName: my-tls
```

`ingressType` selects the flavour: `nginx` (default), `haproxy` for OpenShift routers, or
`gateway` for an `HTTPRoute`. The Gateway API kinds need their CRDs installed — without them the
render is valid but the install fails, which is an environment limit rather than a chart problem.

# Identity repositories

Repositories can be defined in values instead of through the API, keyed by name. Each needs
`tenantId` and `subscriptionId` for tenant scoping:

```yaml
documentsecurity:
  repositories:
    corp-ldap:
      tenantId: "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
      subscriptionId: "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"
      type: ldap
      cronSchedule: "0 0 * * * *"
      config:
        host: ldap.example.com
        port: "389"
        bindDn: cn=admin,dc=example,dc=com
        bindPassword: ""
        baseDn: dc=example,dc=com
```

Each becomes `DOCUMENTSECURITY_REPOSITORIES_<NAME>_*` entries in the ConfigMap. **Bind passwords
supplied this way are rendered into that ConfigMap in plain text** — see
[Known limitations](#known-limitations).

# Credentials and Secrets

For the bundled database the chart generates `password`, `repmgr-password` and `admin-password`
into `<release>-documentsecurity-credentials` on first install and preserves them on upgrade. It
uses Helm's `lookup` to do that, which has two consequences:

- **Never deploy with `helm template | kubectl apply`** — `lookup` returns nothing without a
  cluster, so every apply would mint new credentials and rotate them.
- **Under Argo CD or Flux, do not rely on generation** — they render without cluster access by
  default. Supply your own Secret instead.

Which value names it depends on which database is in use, because the two Secrets are not
interchangeable:

```yaml
# Bundled: bitnami's key names, and the sub-chart must be handed the same Secret.
postgresql:
  existingSecret: my-db-credentials        # keys: password, repmgr-password, admin-password
  postgresql:
    existingSecret: my-db-credentials
  pgpool:
    existingSecret: my-db-credentials

# External: a password, optionally a username, keys named to suit.
externalPostgresql:
  existingSecret: my-db-credentials
  existingSecretPasswordKey: password
  existingSecretUsernameKey: username      # empty keeps the username in the ConfigMap
```

The chart fails the render rather than letting the API and PostgreSQL read different Secrets, and
rejects the combinations that cannot work — a non-default password key alongside the bundled
database, or a username key when bitnami would ignore it.

The generated Secret carries `helm.sh/resource-policy: keep`, so it outlives `helm uninstall` for
as long as the retained PGDATA volume does. A reinstall would otherwise meet an old database with
a new password.

# Uninstalling and cleaning up

`helm uninstall` leaves the bundled database's PersistentVolumeClaims — they are created by the
StatefulSet controller, not by Helm — and the credential Secret above. To discard the release
completely, **destroying all repository and group data**:

```sh
kubectl delete pvc,secret -l app.kubernetes.io/instance=<release> -n <namespace>
```

Then check for `Released` PersistentVolumes, which stay behind with a `Retain` StorageClass.

# Known limitations

- **Single replica.** The API StatefulSet is fixed at one replica; there is no HA configuration.
- **The API has no authentication by default.** `documentsecurity.auth.enabled=true` with
  `auth.jwksUri`, `auth.issuer` and `auth.audience` turns on JWT validation; until then every
  endpoint is open to anything that can reach the Service or Ingress. Even then any valid OTDS
  token is accepted unless `auth.requireValidSubscription=true` (with `auth.etsUrl` and
  `auth.validSubscriptionApplications`) also requires the caller's subscription to be to this
  application.
- **LDAP bind passwords in `documentsecurity.repositories` are rendered into a ConfigMap in plain
  text.** Prefer creating those repositories through the API.
- **The defaults reference an internal registry.** `documentsecurity.image`, the bitnami database
  images and the busybox init image all default to `artifactory.otxlab.net`, and
  `global.imagePullSecrets` expects a Secret named `dockerhub-secret` to exist already.
- **The bitnami `postgresql-ha` images are pinned to the `bitnamilegacy` repositories**, which no
  longer receive updates. Review against your vulnerability policy.
- **The embedded HSQLDB fallback is not persistent** — no volume is mounted for it.
