{{/*
# BEGIN COPYRIGHT NOTICE
# Copyright 2023-2025 Open Text.
#
# The only warranties for products and services of Open Text and its affiliates and licensors
# ("Open Text") are as may be set forth in the express warranty statements accompanying such
# products and services. Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions contained herein.
# The information contained herein is subject to change without notice.
#
# END COPYRIGHT NOTICE
*/}}

{{/*
Base name for this chart's objects, before the release prefix.

A fixed literal rather than .Chart.Name, because a parent chart that takes this chart as an
aliased dependency changes .Chart.Name to the alias - so deriving from it would make the
object names depend on what the parent chose to call the dependency. A parent has to be able
to reference this chart's Service by name, so that name has to be predictable.
*/}}
{{- define "idol-documentsecurity.name" -}}
{{- default "documentsecurity" .Values.documentsecurity.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fully qualified name for this chart's objects: <release>-documentsecurity.

Release-scoped so two releases can coexist in one namespace, which is the whole point of this
helper - the names were once fixed literals, and a second release then collided on every one
of them. The standard Helm rule, including the collapse when the release name already contains
the base name, so a release named `idol-documentsecurity` still gets plain
`idol-documentsecurity`.

fullnameOverride is passed through `tpl`, so a parent chart can supply a release-scoped name
from its own static values and both charts then resolve the same string - see
idol-connector-management, which references this Service from its own templates.
*/}}
{{- define "idol-documentsecurity.fullname" -}}
{{- if .Values.documentsecurity.fullnameOverride -}}
{{- tpl .Values.documentsecurity.fullnameOverride . | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := include "idol-documentsecurity.name" . -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Name the bundled postgresql-ha sub-chart will give its own objects, so this chart can build
the database host from it.

Mirrors bitnami's common.names.fullname against the aliased `postgresql` values, because the
sub-chart computes that name in its own context where nothing here is visible. The default
base name is the alias this chart declares in Chart.yaml, matching what .Chart.Name resolves
to over there.

Note bitnami does NOT pass fullnameOverride through `tpl` - it is used as a literal - so a
release-scoped name has to come from nameOverride, which is why values.yaml sets that instead.
*/}}
{{- define "idol-documentsecurity.postgresql.fullname" -}}
{{- if .Values.postgresql.fullnameOverride -}}
{{- .Values.postgresql.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default "postgresql" .Values.postgresql.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
The user-supplied credential Secret, if there is one, for whichever database is in use.

Each mode has its own value because the two Secrets are not interchangeable: one for the
bundled database has to carry bitnami's key names (password, repmgr-password,
admin-password) and be wired into the sub-chart's own existingSecret values as well, while
one for an external instance needs only a password and may name its keys freely
(externalPostgresql.existingSecretPasswordKey / -UsernameKey). Only one is ever in force, so
reading the mode here keeps each block self-contained.

Both are passed through `tpl`, so a parent chart can supply a release-scoped name from its
own static values - which is how a bundled deployment points this chart at a database, and
its credentials, that the parent owns.
*/}}
{{- define "idol-documentsecurity.postgresql.existingSecret" -}}
{{- if .Values.postgresql.enabled -}}
{{- with .Values.postgresql.existingSecret }}{{ tpl . $ }}{{ end -}}
{{- else -}}
{{- with (.Values.externalPostgresql | default dict).existingSecret }}{{ tpl . $ }}{{ end -}}
{{- end -}}
{{- end -}}

{{/*
Name of the Secret holding the database password.

Derived from the release name rather than a chart fullname when the chart generates it: the
postgresql-ha sub-chart is pointed at this Secret through its own existingSecret values and
`tpl`s them in ITS context, where this chart's values are invisible and would expand to
nothing.
*/}}
{{- define "idol-documentsecurity.postgresql.secretName" -}}
{{- include "idol-documentsecurity.postgresql.existingSecret" . | default (printf "%s-documentsecurity-credentials" .Release.Name) -}}
{{- end -}}

{{- define "idol-documentsecurity.postgresql.passwordKey" -}}
{{- $key := (.Values.externalPostgresql | default dict).existingSecretPasswordKey | default "password" -}}
{{- if and .Values.postgresql.enabled (ne $key "password") -}}
{{- fail (printf "\n\nexternalPostgresql.existingSecretPasswordKey is %q, but the bundled database requires \"password\".\n\nThe postgresql-ha sub-chart references that key name directly, so a different one would\nleave PostgreSQL and the API reading different keys. Use the default, or set\npostgresql.enabled=false and point at an external instance.\n" $key) -}}
{{- end -}}
{{- $key -}}
{{- end -}}

{{/*
Which Secret key holds the username, if any.

External database only. The bundled postgresql-ha sub-chart reads its username from its
values rather than from a Secret, so setting this alongside it would create a second source
of truth that bitnami ignores - reject the combination instead of silently dropping it.

Empty is the usual choice: a username is not secret, and keeping it in the ConfigMap keeps
it visible when debugging an authentication failure. Set it when the credential arrives as
one bundle from a secret store, e.g. an AWS Secrets Manager RDS secret.
*/}}
{{- define "idol-documentsecurity.postgresql.usernameKey" -}}
{{- $key := (.Values.externalPostgresql | default dict).existingSecretUsernameKey | default "" -}}
{{- if and .Values.postgresql.enabled $key -}}
{{- fail (printf "\n\nexternalPostgresql.existingSecretUsernameKey is set (%q) but postgresql.enabled is true.\n\nThe bundled sub-chart takes its username from postgresql.postgresql.username, not from a\nSecret, so this would be a second source of truth that bitnami ignores. Set the username in\nvalues for the bundled database, or use this with an external instance.\n" $key) -}}
{{- end -}}
{{- $key -}}
{{- end -}}

{{/*
Whether a database is configured at all, and therefore whether a password is needed.
False for the embedded-HSQLDB fallback, and when the user supplied a complete connection
string themselves - in which case they supply the credentials with it.
*/}}
{{- define "idol-documentsecurity.postgresql.configured" -}}
{{- if hasKey (.Values.documentsecurity.env | default dict) "DOCUMENTSECURITY_DB_CONNECTIONSTRING" -}}
{{- else if or .Values.externalPostgresql.host .Values.postgresql.enabled -}}
true
{{- end -}}
{{- end -}}

{{/*
Resolve one Secret key to a base64 value: an explicit value if configured, else whatever
is already in the cluster (so it survives `helm upgrade`), else a generated one.

Generation must happen in one template only - every consumer references the Secret rather
than the value, or they would generate different values in the same render.

`lookup` is empty without a cluster, so `helm template` and client-side `--dry-run` show a
fresh value each time and `helm template | kubectl apply` would rotate credentials on every
apply. Use `helm install/upgrade`, or supply your own Secret via postgresql.existingSecret.
*/}}
{{- define "idol-documentsecurity.secretValue" -}}
{{- if .explicit -}}
{{- .explicit | toString | b64enc -}}
{{- else if .generate -}}
{{- $old := (lookup "v1" "Secret" .root.Release.Namespace .name).data | default dict -}}
{{- index $old .key | default (randAlphaNum 32 | b64enc) -}}
{{- else -}}
{{- "" | b64enc -}}
{{- end -}}
{{- end -}}
